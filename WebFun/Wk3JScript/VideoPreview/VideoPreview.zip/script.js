console.log("page loaded...");

var x = document.getElementById("playVid");
function play(element) {
    x.play();
}
function pause(element) {
    x.pause();
}
