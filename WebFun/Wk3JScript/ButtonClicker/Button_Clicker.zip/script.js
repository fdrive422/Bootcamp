function logOff(elementName){
    elementName.innerText = "Log-Off";
}

function hide(elementName){
    elementName.remove();
}