// console.log("page loaded...");

function hide(elementName){
    elementName.remove()
}

// document.getElementById('joinButton').addEventListener('click', function(){
//     document.getElementById('joinBUtton').style = "display: none"
// })

function search(event) {
    event.preventDefault()
    let searchTerm = document.getElementById("searchBar").value
    alert('You are looking for ${searchTerm}')
}   

// let likeCount = 212

// let macaronCount = document.getElementById("macaronCount")

// function likeCount(){
//     likeCount++
//     macaronCount.innerText = likeCount
// }
